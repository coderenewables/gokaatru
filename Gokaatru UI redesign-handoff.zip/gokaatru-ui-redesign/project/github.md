repo: coderenewables/gokaatru
branch: master
path: frontend/src

## Last sync

date: 2026-09-06T10:50:49Z

### Updated in this project

- Read the real app IA (10 primary tabs, 9-stage Stepper, 6 sweep sub-tabs) and the shipped palette from `styles.css`.
- Rebuilt the mockup as "Gokaatru Workspace v2" against the real domain: fixed prefix, 5 sweep axes, 8 admissibility gates, spread reporting.
- Adopted the app's own tokens (cream `#f3efe6`, teal `#0b7a6f`, terracotta `#c86a2a`) and its system-sans / ui-monospace pairing.
- Imported the real brand mark (`frontend/public/gokaatru-logo.png`) into the header.
- v1 mockup kept unchanged as the pre-code-read version.

## Screen map

| Project screen | Built from |
| --- | --- |
| Phase rail + header (Gokaatru Workspace v2) | `frontend/src/components/AppHeader.tsx`, `PhaseTabs.tsx`, `App.tsx` |
| Prepare (session, stages, sensors, fixed prefix) | `frontend/src/lib/stages.ts`, `components/stages/DataLoadView.tsx`, `components/SensorReviewView.tsx` |
| Run (axes + live cost + monitor merged) | `frontend/src/components/sweep/SweepDesigner.tsx`, `SweepMonitor.tsx`, `frontend/src/types/sweep.ts` |
| Interrogate (spread, gates, sensitivity, export) | `frontend/src/components/sweep/SpreadSummaryView.tsx`, `SpreadExplorer.tsx`, `GateReportView.tsx`, `server/core/admissibility.py` |
| Palette / typography | `frontend/src/styles.css` (`:root` tokens) |
| Brand mark (`gokaatru-logo.png`) | `frontend/public/gokaatru-logo.png` |
| Domain framing + known issues in design notes | `CLAUDE.md`, `frontend/src/components/HomeView.tsx` |
